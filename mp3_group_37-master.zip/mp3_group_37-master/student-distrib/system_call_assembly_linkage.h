#ifndef _SYSTEM_CALL_ASM_LINKAGE_H
#define _SYSTEM_CALL_ASM_LINKAGE_H

#include "lib.h"
#include "x86_desc.h"
#include "systemcalls.h"

#ifndef ASM

extern void sys_handler();

#endif
#endif
